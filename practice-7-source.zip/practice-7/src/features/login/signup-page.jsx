import { AuthForm } from "./auth-form";
export default function SignupPage() { return <AuthForm signup />; }
